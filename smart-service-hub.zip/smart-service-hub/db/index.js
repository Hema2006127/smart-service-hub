const { Pool } = require('pg');

const pool = new Pool({
    host:     process.env.DB_HOST,
    port:     parseInt(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME,
    user:     process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    ssl:      { rejectUnauthorized: false }
});

pool.connect()
    .then(client => {
        console.log('✅ Connected to Supabase PostgreSQL');
        client.release();
    })
    .catch(err => console.error('❌ DB Error:', err.message));

module.exports = pool;